//---------------------------------------------------------------------------------------------------------------------------------------------------------------
\\ README FILE - 7/23/2016 - "5 Ways You Could Get Cancer" - Brouchure Android App
//---------------------------------------------------------------------------------------------------------------------------------------------------------------

A. DISCLAIMER
This disclaimer appoints that the content provided in this app is based on personal opinions and theories, and in no circumstance be utilized as factual content unless proven by an expert in the field of the subject.
This app was developed for educational purposes and to share a personal inside on the subject. 5 Ways You Could Get Cancer app is not responsible for, and expressly disclaims all liability for, damages of any kind arising out of use, reference to, or reliance on any information contained within the app.

//---------------------------------------------------------------------------------------------------------------------------------------------------------------
\\
//---------------------------------------------------------------------------------------------------------------------------------------------------------------

B. CONTENT
Topic --> 5 Ways You Could Get Cancer

This app defines what is cancer in a nutshell and enumerates 5 most common sources a human can developed radical cells that may lead to cancerous cells.
The app begins with a header whereas the topic is displayed together to a white ribbon over the background color representing the general cancer ribbon color designated by the ACS, the American Cancer Society. 
The header image bellow depicts the primary stage in which a patient forgoes when they are diagnosed with this condition.
On the content or body section there will be all five possible sources with respective descriptions. The content was animated by adding a max line on the text view and layout_toLeftOf on the view group to conceal some of the content for a better cosmetic view.
By pressing the image buttons pointing up and down you can easily scroll down and up to uncover or hide the additional content to the subject.
At the footer it will display two parts, where at the sub portion of the footer an image button of the ACS logo is displayed and the reader can be redirected to the official site for the American Cancer Society. Including an optional select dialog box that will pop up at pressing the image button.
At the end of the footer a message is displayed with current fact as a motivator to promote the search for more information on the subject.

//---------------------------------------------------------------------------------------------------------------------------------------------------------------
\\
//---------------------------------------------------------------------------------------------------------------------------------------------------------------

C. OPERATIONAL ALGORITHM
1. Open App
2. Scroll down or flip aside the device to view the content
3. By pressing the up image button at any of the 5 subjects, the entire content to the subject selected will appear for reading
4. By pressing the down image button at any of the 5 subjects, the portion that was not showing previously will be conseald back in
5. At the sub footer portion at the American Cancer Society logo, press if interested in visiting the ACS's official web site
6. If the ACS logo is pressed, a dialog box will appear with the request to the reader if they wish to proceed to the ACS's official site or not
7. If the 'Yes' button is pressed, the reader is automatically transfered to the ACS' official site
8. If the 'No' button is pressed, the app automatically dismissed the dialog box option and keeps the reader at the app
9. At the bottom of the footer, the reader will read some current factors in regards to the subject that will motivate user to continue seeking more information, thus minimizing the bouncing rate
10. Exit App

//---------------------------------------------------------------------------------------------------------------------------------------------------------------
\\
//---------------------------------------------------------------------------------------------------------------------------------------------------------------

D. ALGORITHM HIERARCHY

                                                                         +----------+
									 | OPEN APP |
									 +----------+
									       ^
								      	       |
								        +--------------+	   
									|  SCROLL DOWN |
                                                                        +--------------+
                                                                               ^
                                                                               |
									+----------------+ 
									| SELECT SUBJECT |
									+----------------+         
								                ^
                                                                                |											
                                                                   +-------------------------+  
					         		   | PRESS DOWN IMAGE BUTTON |
                                                                   +-------------------------+	
							                         ^
								    		 |
									+--------------+		
									| READ CONTENT |
									+--------------+
									        ^
										|
							          +-----------------------+		
							          | PRESS UP IMAGE BUTTON |
							          +-----------------------+
							           ^
								   |
				         +---------------------------+				
				         | SCROLL DOWN TO SUB FOOTER |
					 +---------------------------+
					     ^                  ^
					     |                  |
+----------------------------------------------------+	     +-------------------------+																
| CLICK ACS LOGO IF INTERESTED TO VISIT THE ACS SITE |       |  DONT CLICK ON ACS LOGO |
+----------------------------------------------------+       +-------------------------+
                        ^
		        |
		   +---------------------------+			
		   | SELECT FROM DIALOG OPTION |
		   +---------------------------+
		      ^                       ^ 
                      |			      |
		   +-----+		   +----+
	           | YES |                 | NO |
		   +-----+                 +----+
		      ^                        ^
		      |                        |
+---------------------------------+  +------------------+
| REDIRECTED TO ACS OFFICIAL SITE |  | STAY ON THE SITE |
+---------------------------------+  +------------------+
                            ^             ^
			    |             |
                +---------------------------------+		
		| READ FACTS AT THE BOTTOM FOOTER |
	        +---------------------------------+
		                   ^
				   |
		    	     +----------+   
			     | EXIT APP |
			     +----------+
							   
//---------------------------------------------------------------------------------------------------------------------------------------------------------------
\\
//---------------------------------------------------------------------------------------------------------------------------------------------------------------
									   
RESOURCES
https://www.thoracic.org/copd-guidelines/for-patients/why-do-i-need-oxygen-therapy.php
http://www.ncbi.nlm.nih.gov/pubmed/1443237
http://www.ncbi.nlm.nih.gov/pmc/articles/PMC3937982/

//---------------------------------------------------------------------------------------------------------------------------------------------------------------
\\
//---------------------------------------------------------------------------------------------------------------------------------------------------------------

REFERENCES
1.	Mike A. (2004) How to give yourself cancer. 
2.	Smith, E. F. (n.d.). The causes of cancer. A review. 

