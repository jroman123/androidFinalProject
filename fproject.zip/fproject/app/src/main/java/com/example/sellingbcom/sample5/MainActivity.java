package com.example.sellingbcom.sample5;

import android.app.Activity;
import android.app.Dialog;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * SHOW DIALOG BOX
 */
public class MainActivity extends Activity {

    TextView introText, content1Text, content2Text, content3Text, content4Text, content5Text, conclusionText;
    ImageButton showIntro, hideIntro, showContent1, hideContent1, showContent2, hideContent2, showContent3, hideContent3, showContent4, hideContent4, showContent5, hideContent5, showConclusion, hideConclusion;

    public void openDialog() {
        final Dialog dialog = new Dialog(this); // Context, this, etc.
        dialog.setContentView(R.layout.dialog_demo);
        dialog.setTitle(R.string.content1);
        dialog.show();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

            setContentView(R.layout.activity_main);


/**
 * Start Introduction Drop Down
 */
        introText = (TextView) findViewById(R.id.intro_text);
        showIntro = (ImageButton) findViewById(R.id.showIntro);
        showIntro.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                System.out.println("Show button");
                showIntro.setVisibility(View.INVISIBLE);
                hideIntro.setVisibility(View.VISIBLE);
                introText.setMaxLines(Integer.MAX_VALUE);

            }
        });
        hideIntro = (ImageButton) findViewById(R.id.hideIntro);
        hideIntro.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                System.out.println("Hide button");
                hideIntro.setVisibility(View.INVISIBLE);
                showIntro.setVisibility(View.VISIBLE);
                introText.setMaxLines(5);

            }
        });
/**
 * End Introduction Drop Down
 */
        /**
         * Start Content1 Drop Down
         */
        content1Text = (TextView) findViewById(R.id.content1_text);
        showContent1 = (ImageButton) findViewById(R.id.showContent1);
        showContent1.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                System.out.println("Show button");
                showContent1.setVisibility(View.INVISIBLE);
                hideContent1.setVisibility(View.VISIBLE);
                content1Text.setMaxLines(Integer.MAX_VALUE);

            }
        });
        hideContent1 = (ImageButton) findViewById(R.id.hideContent1);
        hideContent1.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                System.out.println("Hide button");
                hideContent1.setVisibility(View.INVISIBLE);
                showContent1.setVisibility(View.VISIBLE);
                content1Text.setMaxLines(5);

            }
        });
/**
 * End Content1 Drop Down
 */
        /**
         * Start Content2 Drop Down
         */
        content2Text = (TextView) findViewById(R.id.content2_text);
        showContent2 = (ImageButton) findViewById(R.id.showContent2);
        showContent2.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                System.out.println("Show button");
                showContent2.setVisibility(View.INVISIBLE);
                hideContent2.setVisibility(View.VISIBLE);
                content2Text.setMaxLines(Integer.MAX_VALUE);

            }
        });
        hideContent2 = (ImageButton) findViewById(R.id.hideContent2);
        hideContent2.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                System.out.println("Hide button");
                hideContent2.setVisibility(View.INVISIBLE);
                showContent2.setVisibility(View.VISIBLE);
                content2Text.setMaxLines(5);

            }
        });
/**
 * End Content2 Drop Down
 */
        /**
         * Start Content3 Drop Down
         */
        content3Text = (TextView) findViewById(R.id.content3_text);
        showContent3 = (ImageButton) findViewById(R.id.showContent3);
        showContent3.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                System.out.println("Show button");
                showContent3.setVisibility(View.INVISIBLE);
                hideContent3.setVisibility(View.VISIBLE);
                content3Text.setMaxLines(Integer.MAX_VALUE);

            }
        });
        hideContent3 = (ImageButton) findViewById(R.id.hideContent3);
        hideContent3.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                System.out.println("Hide button");
                hideContent3.setVisibility(View.INVISIBLE);
                showContent3.setVisibility(View.VISIBLE);
                content3Text.setMaxLines(5);

            }
        });
/**
 * End Content3 Drop Down
 */
        /**
         * Start Content4 Drop Down
         */
        content4Text = (TextView) findViewById(R.id.content4_text);
        showContent4 = (ImageButton) findViewById(R.id.showContent4);
        showContent4.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                System.out.println("Show button");
                showContent4.setVisibility(View.INVISIBLE);
                hideContent4.setVisibility(View.VISIBLE);
                content4Text.setMaxLines(Integer.MAX_VALUE);

            }
        });
        hideContent4 = (ImageButton) findViewById(R.id.hideContent4);
        hideContent4.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                System.out.println("Hide button");
                hideContent4.setVisibility(View.INVISIBLE);
                showContent4.setVisibility(View.VISIBLE);
                content4Text.setMaxLines(5);

            }
        });
/**
 * End Content4 Drop Down
 */
        /**
         * Start Content5 Drop Down
         */
        content5Text = (TextView) findViewById(R.id.content5_text);
        showContent5 = (ImageButton) findViewById(R.id.showContent5);
        showContent5.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                System.out.println("Show button");
                showContent5.setVisibility(View.INVISIBLE);
                hideContent5.setVisibility(View.VISIBLE);
                content5Text.setMaxLines(Integer.MAX_VALUE);

            }
        });
        hideContent5 = (ImageButton) findViewById(R.id.hideContent5);
        hideContent5.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                System.out.println("Hide button");
                hideContent5.setVisibility(View.INVISIBLE);
                showContent5.setVisibility(View.VISIBLE);
                content5Text.setMaxLines(5);

            }
        });
/**
 * End Content5 Drop Down
 */
    }

    /**
     * GET DIALOG BOX TO VIEW
     *
     * @param view
     */
    public void submit(View view) {
        CustomDialogClass cdd = new CustomDialogClass(MainActivity.this);
        cdd.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        cdd.show();
    }

    /**
     * START DIALOG BOX
     */
    public class CustomDialogClass extends Dialog implements
            android.view.View.OnClickListener {

        public Activity c;
        public Dialog d;
        public Button yes, no;

        public CustomDialogClass(Activity a) {
            super(a);
            // TODO Auto-generated constructor stub
            this.c = a;
        }

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            requestWindowFeature(Window.FEATURE_NO_TITLE);
            setContentView(R.layout.dialog_demo);
            yes = (Button) findViewById(R.id.btn_yes);
            no = (Button) findViewById(R.id.btn_no);
            yes.setOnClickListener(this);
            no.setOnClickListener(this);

        }
//SWITCH CASE INSTED OF IF

        /**
         * BUT IF ELSE OPTION WAS USED THEN
         * public void onClick(View v) {
         * if(v.getId() == R.id.btn_yes) {
         * <p/>
         * String url = "http://www.cancer.org/index";
         * Intent i = new Intent(Intent.ACTION_VIEW);
         * i.setData(Uri.parse(url));
         * startActivity(i);
         * // c.finish();
         * <p/>
         * }else if (v.getId() == R.id.btn_no){
         * <p/>
         * dismiss();
         * <p/>
         * }else{
         * <p/>
         * dismiss();
         * <p/>
         * }
         * }
         */
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.btn_yes:
                    //IF RETURN IS TRUE USER IS REDIRECTED TO SITE
                    String url = "http://www.cancer.org/index";

                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(url));
                    startActivity(i);

                    // c.finish();
                    break;
                case R.id.btn_no:
                    //IF RETURN IS FALSE USER STAYS ON THE APP
                    dismiss();
                    break;
                default:
                    break;
            }
            dismiss();
        }
    }
}